package com.example.oop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
