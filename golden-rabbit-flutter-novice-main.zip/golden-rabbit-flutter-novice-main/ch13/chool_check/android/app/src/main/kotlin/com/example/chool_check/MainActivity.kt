package com.example.chool_check

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
