package com.example.async_programming

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
