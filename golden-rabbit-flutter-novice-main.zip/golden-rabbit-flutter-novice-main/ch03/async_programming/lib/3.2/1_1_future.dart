void main(){
  Future<String> name;    // 미래에 받을 String값
  Future<int> number;     // 미래에 받을 int값
  Future<bool> isOpened;  // 미래에 받을 boolean값
}