package com.example.basic_widgets

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
