package com.example.image_carousel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
