# image_carousel

## 완성 스크린샷

![image](./asset/final/final_screenshot.png)