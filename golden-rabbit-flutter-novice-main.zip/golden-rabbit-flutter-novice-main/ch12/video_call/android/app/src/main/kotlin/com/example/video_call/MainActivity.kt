package com.example.video_call

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
