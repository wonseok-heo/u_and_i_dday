const APP_ID = '앱ID를 입력해주세요!!!';

const CHANNEL_NAME = '채널 이름을 입력해주세요!!!';

const TEMP_TOKEN = '토큰값을 입력해주세요!!!';
