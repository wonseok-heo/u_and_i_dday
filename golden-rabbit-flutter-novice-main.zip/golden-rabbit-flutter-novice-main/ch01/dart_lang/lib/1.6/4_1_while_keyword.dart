void main(){
  int total = 0;

  while(total < 10){  // total 값이 10보다 작으면 계속 실행
    total += 1;
  }

  print(total);
}
