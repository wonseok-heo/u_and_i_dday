void main(){
  int total = 0;

  do {
    total += 1;
  } while(total < 10);

  print(total);
}
