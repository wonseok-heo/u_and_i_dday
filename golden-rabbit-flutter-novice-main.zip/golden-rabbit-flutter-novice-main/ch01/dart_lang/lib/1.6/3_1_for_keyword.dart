void main() {
  // 값 선언; 조건 설정; loop 마다 실행할 기능
  for (int i = 0; i < 3; i++) {
    print(i);
  }
}
