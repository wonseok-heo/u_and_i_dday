void main(){
  // String - 문자열
  String name = '코드팩토리';

  // int - 정수
  int isInt = 10;

  // double - 실수
  double isDouble = 2.5;

  // bool - 불리언 (true/false)
  bool isTrue = true;

  print(isInt);
  print(isDouble);
  print(isTrue);
}
