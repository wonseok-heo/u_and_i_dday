void main() {
  dynamic name = '코드팩토리';
  name = 1;
}
