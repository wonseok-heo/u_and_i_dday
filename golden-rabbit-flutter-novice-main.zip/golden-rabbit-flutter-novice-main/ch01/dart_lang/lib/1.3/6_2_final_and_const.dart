void main() {
  final DateTime now = DateTime.now();

  print(now);
}
