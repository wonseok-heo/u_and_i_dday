void main(){
  // 콘솔에 출력
  print('Hello World');
}
