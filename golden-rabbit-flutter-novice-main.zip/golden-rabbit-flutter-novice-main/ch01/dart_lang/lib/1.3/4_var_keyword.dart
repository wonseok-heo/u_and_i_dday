void main(){
  var name = '코드팩토리';
  print(name);

  // 변숫값 변경 가능
  name = '골든래빗';
  print(name);

  // 변수명 중복은 불가능
  // 그래서 다음 코드에서 주석 기호를 제거하면 코드에서 에러 발생
  // var name = ‘김고은';
}
