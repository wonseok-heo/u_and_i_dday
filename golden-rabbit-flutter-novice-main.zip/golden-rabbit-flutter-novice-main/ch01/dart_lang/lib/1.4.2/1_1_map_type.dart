void main() {
  Map<String, String> dictionary = {
    'Harry Potter': '해리 포터',        // 키 : 값
    'Ron Weasley': '론 위즐리',
    'Hermione Granger': '헤르미온느 그레인저',
  };
  print(dictionary['Harry Potter']);
  print(dictionary['Hermione Granger']);
}
