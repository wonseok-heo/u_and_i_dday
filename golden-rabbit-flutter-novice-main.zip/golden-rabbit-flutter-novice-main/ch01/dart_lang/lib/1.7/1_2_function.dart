int addTwoNumbers({
  required int a,
  required int b,
}) {
  return a + b;
}

void main() {
  print(addTwoNumbers(a: 1, b: 2));
}
