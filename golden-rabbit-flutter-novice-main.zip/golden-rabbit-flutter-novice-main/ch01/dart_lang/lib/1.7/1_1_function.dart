int addTwoNumbers(int a, int b) {
  return a + b;
}

void main() {
  print(addTwoNumbers(1, 2));
}
