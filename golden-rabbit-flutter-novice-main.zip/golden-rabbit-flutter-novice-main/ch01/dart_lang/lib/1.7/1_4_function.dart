int addTwoNumbers({
  required int a,
  int b = 2,
}) {
  return a + b;
}

void main() {
  print(addTwoNumbers(a: 1));
}
