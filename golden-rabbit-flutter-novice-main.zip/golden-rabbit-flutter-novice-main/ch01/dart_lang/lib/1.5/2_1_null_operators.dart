void main() {
  // 타입 뒤에 ?를 명시해서 null값을 가질 수 있습니다.
  double? number1 = 1;

  // 타입 뒤에 ?를 명시하지 않아 에러가 납니다.
  // double number2 = null;
}
