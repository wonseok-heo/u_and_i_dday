void main() {
  double number = 2;

  print(number + 2); // 4 출력
  print(number - 2); // 0 출력
  print(number * 2); // 4 출력
  print(number / 2); // 1 출력. 나눈 몫
  print(number % 3); // 2 출력. 나눈 나머지

  // 단항 연산도 됩니다.
  number++; // 3
  number--; // 2
  number += 2; // 4
  number -= 2; // 2
  number *= 2; // 4
  number /= 2; // 1
}
