package com.example.dart_lang

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
