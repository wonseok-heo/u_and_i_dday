package com.example.blog_web_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
