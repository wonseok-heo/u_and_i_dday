const API_KEY = 'GCP에서 발급받은 토큰을 입력해주세요!!!';
const YOUTUBE_API_BASE_URL = 'https://youtube.googleapis.com/youtube/v3/search'; // Youtube Data API V3 URL
const CF_CHANNEL_ID = 'UCxZ2AlaT0hOmxzZVbF_j_Sw'; // 코드팩토리 채널 ID