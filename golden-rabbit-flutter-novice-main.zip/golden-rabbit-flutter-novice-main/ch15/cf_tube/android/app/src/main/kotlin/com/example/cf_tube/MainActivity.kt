package com.example.cf_tube

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
