package com.example.image_editor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
