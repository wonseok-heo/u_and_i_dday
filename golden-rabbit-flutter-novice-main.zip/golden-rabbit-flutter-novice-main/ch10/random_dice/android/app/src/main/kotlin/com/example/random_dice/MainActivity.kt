package com.example.random_dice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
