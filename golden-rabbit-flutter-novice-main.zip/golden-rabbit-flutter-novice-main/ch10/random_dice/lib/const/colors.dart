import 'package:flutter/material.dart';

const backgroundColor = Color(0xFF0E0E0E);  // 배경색

const primaryColor = Colors.white;  // 주 색상

final secondaryColor = Colors.grey[600];  // 보조 색상